<?php 
	echo "Example work....";
?>